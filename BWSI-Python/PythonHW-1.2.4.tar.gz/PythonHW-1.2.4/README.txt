Python BWSI-EdX Graded Assignments
------------------------------------
These problems are ordered alphabetically, and *not* in order of ascending difficulty. Please consult the BWSI-EdX course page for the due dates for the respective problems.

In order to run the auto-grader for these problems, you must install bwsi_grader. In your terminal, execute:

pip install bwsi_grader

This grader requires you to use Python 3.6 or later.
